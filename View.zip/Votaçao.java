public class Votaçao {

   int numSec;
   int numVot;

Votaçao(){
    
     numSec = 0;
     numVot =0;
}

 Votaçao(int NumeroSe, int NumeroVot){
     numSec = NumeroSe;
     numVot = NumeroVot;
 }
}
