public class Main {
    
                Transito[] t = new Transito[3];
                 View v = new View();
    
        	public void acidentesAcimaMedia(Transito[] t) {
		// TODO Auto-generated method stub
		double soma = 0;
		for (int i = 0 ; i < t.length ; i++) {
			soma =+ soma + t[i].qtdAcidentes;
		}
		double media = soma / t.length;
		
		System.out.println("Cidades com num de acidentes maior");
		for (int i = 0 ; i<t.length ; i++) {
			if(t[i].qtdAcidentes > media) {
				System.out.println(t[i].toString());
			}
		}
	}

	public void consultaEstatistica(Transito[] t) {
		// TODO Auto-generated method stub
		
	}

	public void consultaQuantidade(Transito[] t) {
		// TODO Auto-generated method stub
		
	}

	public void cadastrroEstat(Transito[] t) {
		// TODO Auto-generated method stub
		
	}
}
