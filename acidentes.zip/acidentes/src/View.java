
import javax.swing.JOptionPane;

public class View {
    public static void main(String args[]){
    int n = 0;
    
    Transito[] t = new Transito[3];
   
    
       	for(int i = 0 ; i < t.length ; i++) {
                t[i] = new Transito();
  		t[i].codigoCidade = Integer.parseInt(JOptionPane.showInputDialog("codigo da cidade"));
  		t[i].nomeCidade = JOptionPane.showInputDialog("nome da cidade");
		t[i].qtdAcidentes = Integer.parseInt(JOptionPane.showInputDialog("quantidade de acidentes"));
	}
  	
            while(n != 9) {
		    
            n = Integer.parseInt(JOptionPane.showInputDialog("| Estatísticas de acidentes em 2020|\n" +
		 "digite..." +
		"| 1 - Cadastro Estatística			|\n" +
		 "| 2 - Consulta por quantidade de acidentes	|\n" +
		 "| 3 - Consulta por estatísticas de acidentes	|\n" +
		 "| 4 - Acidentes acima da média das 10 cidades   |\n" +
		 "| 9 - Finaliza 	 "));
			switch (n)
			 {
			       case 1:
			            cadastrroEstat(t);
			       break; 
			            
			        case 2:
			            consultaQuantidade(t);
			        break;
			        
			        case 3:
			            consultaEstatistica(t);
			        break;
			        
			        case 4:
			            acidentesAcimaMedia(t);
			        break;
                                case 9:
                                    JOptionPane.showMessageDialog(null,"finalizando sistema");
                                    break;
			        default:
			            JOptionPane.showMessageDialog(null,"numero invalido digite outro numero");

             }
	}
	
}
}

