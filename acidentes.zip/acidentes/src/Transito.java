
public class Transito {
    
	    int codigoCidade ; 
	    String nomeCidade;
	    int qtdAcidentes;
	    
	    Transito()
	    {
	        codigoCidade = 0;
	        nomeCidade = "";
	        qtdAcidentes = 0;     
	    }
	    
	    Transito(int codCid,String nomeCid,int qantAci)    
	    {
	      codigoCidade = codCid;
	      nomeCidade = nomeCid;
	      qtdAcidentes = qantAci;       
	    }
	    
	    @Override
	    public String toString() {
	    // TODO Auto-generated method stub
	    	
	    	String retorno = codigoCidade + ", " + nomeCidade + ", " + qtdAcidentes;
	    return retorno;
	    }
}

